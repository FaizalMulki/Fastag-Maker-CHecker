﻿app.controller("FastagListController", function ($scope, $http,$filter) {
    $scope.model = {};
    $scope.model.txtSearch = "";
    $scope.model.FromDate = moment().subtract(30, "days").format("DD-MM-YYYY");
    $scope.model.ToDate = moment().add(1, 'days').format("DD-MM-YYYY");

    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.GroupSearch = function () {
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }

    $scope.checkData = function (e) {
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }


    $scope.mainGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + "Fastag/GetAllItems",
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    
                    var opt = {};
                    opt = options;
                    opt.Search = $scope.model.txtSearch;
                    opt.FromDate = $scope.model.FromDate;
                    opt.ToDate = $scope.model.ToDate;
                    return opt;
                },
            },
            schema:
                    {
                        model:
                        {
                            id: "Id",
                            fields: {

                            }
                        }
                    },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },

        sortable: {
            mode: "single",
            allowUnsort: true
        },


        pageable: { pageSize: GridPageSize, refresh: true },

        resizeable: true,
        scrollable: false,

        columns: [
             {
                 field: "ReferenceNumber",
                 title: "Ref.Number",
                 width: "80px",
                 filterable: false,

             },
               {
                   field: "VehicleType",
                   title: "Type",
                   width: "80px",
                   filterable: false,

               },
                {
                    field: "FirstName",
                    title: "First Name",
                    width: "80px",
                    filterable: false,

                },
                 {
                     field: "LastName",
                     title: "Last Name",
                     width: "80px",
                     filterable: false,

                 },
                  {
                      field: "Email",
                      title: "Email",
                      width: "80px",
                      filterable: false,

                  },
                   {
                       field: "Mobile",
                       title: "Mobile",
                       width: "80px",
                       filterable: false,

                   },
                   {
                       field: "CreatedBy",
                       title: "CreatedBy",
                       width: "80px",
                       filterable: false,

                   },

                {
                    field: "CreatedDate",
                    title: "Created Date",
                    width: "120px",
                    type: "date",
                    format: "{0:dd-MMM-yyyy}"

                },
                
                {
                    field: "StatusName",
                    title: "Status",
                    width: "80px",
                    filterable: false,

                },


           {
               template: "<a href='javascript:void(0);' class='btn-edit'  ng-click='Edit(this)'  data-toggle='tooltip' title='Edit'><i class='las la-pen'></i></a> &nbsp; <a href='javascript:void(0);' class='btn-delete' ng-click='deleteReg(this)'  data-toggle='tooltip' title='Delete'><i class='las la-trash-alt'></i></a>",
               width: "40px",
               title: "Action",
               headerAttributes: { style: "text-align:center;" },
               attributes: { style: "text-align:center;" },
           },

        ]
    };


    $scope.Registration = function (e) {
        window.location = "/Fastag/Registration";
    }
    $scope.Edit=function(e)
    {
        
        var Id=e.dataItem.Id;
        window.location = "/Fastag/Edit?Id=" + Id;
    }
   

  $scope.Search=function()
  {
      $("#mainGrid").data("kendoGrid").dataSource.read();
  }
  $scope.deleteReg = function (e) {
      $scope.DeleteModel = {};
      var warnText = "Are you sure you want to delete this record?";
      $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
          if (confirmed) {
              $scope.ShowLoaderImg();
              $scope.DeleteModel.Id = e.dataItem.Id;
              $http({
                  method: 'POST',
                  url: baseUrl + 'Fastag/DeleteRegistration',
                  data: $scope.DeleteModel,
              }).then(function (response) {
                  debugger;
                  $scope.HideLoaderImg();
                  if (response.data == 'dependency') {
                      SetMessage('CantDelete')
                  }
                  else if (response.data == 'success') {
                      SetMessage('Delete')
                  }
                  else {
                      SetMessage('Error');
                  }
                  $("#mainGrid").data("kendoGrid").dataSource.read();


              }, function errorCallback(response) {
                  $scope.HideLoaderImg();
                  SetMessage('Error');

              });
          }
      });
  }

   

});