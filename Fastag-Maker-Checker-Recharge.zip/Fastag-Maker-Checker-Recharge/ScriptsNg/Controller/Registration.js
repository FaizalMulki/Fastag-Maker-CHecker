﻿app.controller("FastagRegistrationController", function ($scope, $http, $filter) {
    $scope.Uploads = [];
    $scope.VehicleUploads = [];
    $scope.CanProceed = false;
    $scope.DeletedAttachId = [];
    $scope.Attachments = {};
    $scope.model = {};
    $scope.model.Id = GetParameterValue("Id", 0);
    $scope.model.IsEdit = false;


    $scope.CloseIDPopup = function (e) {
        debugger;
        $scope.attachmentListWindow.center().close();
    }

    $scope.CloseVehiclePopup = function (e) {
        debugger;
        $scope.attachmentListVehicleWindow.center().close();
    }
    $scope.ClosePANPopup = function (e) {
        debugger;
        $scope.attachmentListPANWindow.center().close();
    }

    $scope.OpenPANAttachmentWindow = function (e) {
        debugger;
        $scope.attachmentListPANWindow.center().open();
    }


    


    $scope.OpenAttachmentWindow = function (e) {
        debugger;
        $scope.attachmentListWindow.center().open();
    }


    $scope.OpenVehicleAttachmentWindow = function (e) {
        debugger;
        $scope.attachmentListVehicleWindow.center().open();
    }
    

    $scope.CheckPAN= function (obj)
    {
        $scope.model.PAN = obj;
       
        //$scope.winvehicleattachmentname = "Vehicle Proof-" + $scope.model.VehicleProof + "-" + count;
        $scope.winPANname = $scope.model.PAN;
    }
    $scope.CheckButton = function (obj) {
        $scope.model.IdProof = obj;
      
        $scope.winattachmentname =  $scope.model.IdProof;
    }

    $scope.CheckVehicleButton = function (obj) {
        $scope.model.VehicleProof = obj;
       
        $scope.winvehicleattachmentname =  $scope.model.VehicleProof;
    }

    $scope.OpenPopupWindow = function () {
      
         $scope.model.IdProof = 'AadharCard'
      
        $scope.winattachmentname = $scope.model.IdProof;
        $scope.WinAttachment.setOptions("");
        $scope.WinAttachment.open().center();
    }

    
    $scope.OpenVehiclePopupWindow = function () {
       
        $scope.model.VehicleProof = 'RC'
      
        $scope.winvehicleattachmentname =  $scope.model.VehicleProof;
        $scope.WinVehicleAttachment.setOptions("");
        $scope.WinVehicleAttachment.open().center();
    }



    $scope.OpenPANPopupWindow = function () {
      
      
        $scope.model.PAN = 'PANCard'
        
        //$scope.winvehicleattachmentname = "Vehicle Proof-" + $scope.model.VehicleProof + "-" + count;
        $scope.winPANname = $scope.model.PAN;
        $scope.WinPANAttachment.setOptions("");
        $scope.WinPANAttachment.open().center();
    }




    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }




    $scope.GetDetails = function () {
        debugger;
        var id = parseInt($scope.model.Id);
        if (id > 0) {

            debugger
            $http({
                method: "Get",
                url: baseUrl + 'Fastag/GetDetails?Id=' + $scope.model.Id,
                showloader: true,
            }).success(function (response) {
                debugger
                $scope.model = {};
                if (response) {
                    for (var i = 0; i < response.length; i++) {
                        $scope.model.IsEdit = true;
                        $scope.model.Id = response[i].Id;
                        $scope.model.FirstName = response[i].FirstName;
                        $scope.model.LastName = response[i].LastName;
                        $scope.model.Email = response[i].Email;
                        $scope.model.Phone = response[i].Phone;
                        $scope.model.Mobile = response[i].Mobile;
                        $scope.model.DeliveryAddress = response[i].DeliveryAddress;
                        $scope.model.VehicleRegNo = response[i].VehicleRegNo;
                        $scope.model.VehicleTypeId = response[i].VehicleTypeId;
                        SetComboValue("VehicleTypeId", response[i].VehicleTypeId);
                        $scope.model.PaymentType = response[i].PaymentType;
                        $scope.model.FromAccountNumber = response[i].FromAccountNumber;
                        $scope.model.ToAccountNumber = response[i].ToAccountNumber;

                        $scope.model.SecurityDeposit = response[i].SecurityDeposit;
                        $scope.model.FastagFee = response[i].FastagFee;
                        $scope.model.MinimumBalanceDeposit = response[i].MinimumBalanceDeposit;
                        $scope.model.Others = response[i].Others
                        $scope.model.TotalPayable = response[i].TotalPayable;

                        $scope.model.FatherName = response[i].FatherName;
                        $scope.model.DOB = kendo.toString(response[i].DOB, 'dd-MMM-yyyy');

                        //var NewDate = kendo.toString(response[i].DOB, 'dd-MMM-yyyy');
                        //$("#DOB").data('kendoDatePicker').value(NewDate);



                        $scope.model.FinacleTransNumber = response[i].FinacleTransNumber;



                        $scope.GetAttachments(id);
                    }

                }



            });
        }
        else {

            $scope.model.PaymentType = 'Transfer'
        }
    }

    $scope.GetDetails();

    $scope.Update = function () {
        if ($scope.validator.validate()) {
            debugger;
            $scope.ShowLoaderImg();
            $scope.Registration = {};
            $scope.Registration.Id = $scope.model.Id;
            $scope.Registration.FirstName = $scope.model.FirstName;
            $scope.Registration.LastName = $scope.model.LastName;
            $scope.Registration.Email = $scope.model.Email;
            $scope.Registration.Phone = $scope.model.Phone;
            $scope.Registration.Mobile = $scope.model.Mobile;
            $scope.Registration.DeliveryAddress = $scope.model.DeliveryAddress;
            $scope.Registration.VehicleTypeId = getComobBoxValue("VehicleTypeId");
            $scope.Registration.VehicleRegNo = $scope.model.VehicleRegNo;
            $scope.Registration.PaymentType = $scope.model.PaymentType;
            $scope.Registration.FromAccountNumber = $scope.model.FromAccountNumber;
            $scope.Registration.ToAccountNumber = $scope.model.ToAccountNumber;
            $scope.Registration.FatherName = $scope.model.FatherName;
            $scope.Registration.DOB = $scope.model.DOB;
            $scope.Registration.SecurityDeposit = $scope.model.SecurityDeposit;
            $scope.Registration.FastagFee = $scope.model.FastagFee;
            $scope.Registration.MinimumBalanceDeposit = $scope.model.MinimumBalanceDeposit;
            $scope.Registration.Others = $scope.model.Others;
            $scope.Registration.TotalPayable = $scope.model.TotalPayable;
        }

        $http({
            method: 'POST',
            url: baseUrl + 'Fastag/UpdateRegistration',
            data: $scope.Registration,
        }).then(function (response) {
            debugger;
            $scope.HideLoaderImg();

            if (response.data == 'error') {
                SetMessage('Error')
            }

            else {


                $scope.submitFiles($scope.model.Id);
                //$scope.WinGroup.close();
                //SetMessage('Save')
                SetMessage("Save");

                window.location = "/Fastag/List";

                //$("#mainGrid").data("kendoGrid").dataSource.read();
            }

        }, function errorCallback(response) {
            $scope.HideLoaderImg();
            SetMessage('Error');

        });


    }
    $scope.Save = function () {
        debugger

        if ($scope.validator.validate()) {

            if ($scope.CanProceed) {
                $scope.ShowLoaderImg();
                var params = $scope.Settings;
                $scope.Registration = {};
                $scope.Registration.Id = $scope.model.Id;
                $scope.Registration.FirstName = $scope.model.FirstName;
                $scope.Registration.LastName = $scope.model.LastName;
                $scope.Registration.Email = $scope.model.Email;
                $scope.Registration.Phone = $scope.model.Phone;
                $scope.Registration.Mobile = $scope.model.Mobile;
                $scope.Registration.DeliveryAddress = $scope.model.DeliveryAddress;
                $scope.Registration.VehicleTypeId = getComobBoxValue("VehicleTypeId");
                $scope.Registration.VehicleRegNo = $scope.model.VehicleRegNo;
                $scope.Registration.PaymentType = $scope.model.PaymentType;
                $scope.Registration.FromAccountNumber = $scope.model.FromAccountNumber;
                $scope.Registration.ToAccountNumber = $scope.model.ToAccountNumber;
                $scope.Registration.FatherName = $scope.model.FatherName;
                $scope.Registration.DOB = $scope.model.DOB;
                $scope.Registration.SecurityDeposit = $scope.model.SecurityDeposit;
                $scope.Registration.FastagFee = $scope.model.FastagFee;
                $scope.Registration.MinimumBalanceDeposit = $scope.model.MinimumBalanceDeposit;
                $scope.Registration.Others = $scope.model.Others;
                $scope.Registration.TotalPayable = $scope.model.TotalPayable;


                $http({
                    method: 'POST',
                    url: baseUrl + 'Fastag/OrigRegistration',
                    data: $scope.Registration,
                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg();

                    if (response.data == 'error') {
                        SetMessage('Error')
                    }
                    else if (response.data == 'actDoesntExistOrBalanced') {
                        SetMessage('ActDoesntExistOrBalaned')
                    }
                    else if (response.data == 'insuffiecient') {
                        SetMessage('Insufficient')
                    }
                    else if (response.data == 'invalidaccount') {
                        SetMessage('InvalidAccount')
                    }
                    else if (response.data == 'exceptionBal') {
                        SetMessage('BalException')
                    }
                    else if (response.data == 'exceptionTrans') {
                        SetMessage('TransException')
                    }
                    else {

                        var Id = parseInt(response.data);
                        $scope.submitFiles(Id);

                        SetMessage("Save");

                        window.location = "/Fastag/List";


                    }

                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
            else {
                SetMessage('NoData');
            }
        }
    }


    $scope.GetAttachments = function (ReferenceId) {
        debugger

        $.ajax({
            method: 'POST',
            url: baseUrl + '/Fastag/GetDocuments',
            data: {
                referenceid: ReferenceId,

            },
            async: false,
            success: function (response) {
                debugger;
                $scope.Uploads = [];
                $scope.Attachments = response.Data;
                $scope.hasVehicleAttach = false;
                $scope.hasPANAttach = false;
                $scope.hasIdAttach = false;
                for(var i=0;i<$scope.Attachments.length;i++)
                {
                    if($scope.Attachments[i].IsVehicle==1)
                    {
                       
                        $scope.hasVehicleAttach = true;
                       
                    }
                    if($scope.Attachments[i].IsVehicle==0 && $scope.Attachments[i].IsPAN==1 )
                    {
                        $scope.hasPANAttach = true;
                    }
                    if ($scope.Attachments[i].IsVehicle == 0 && $scope.Attachments[i].IsPAN == 0) {
                        $scope.hasIdAttach = true;
                    }
                }
            }
        });

    }



    $scope.AddFile = function () {
        var len = $scope.Uploads.length;
        if ($("#File1").prop("files")[0] != undefined) {
            var x = $("#File1").prop("files")[0];
            var y = x.name.substr((x.name.lastIndexOf('.') + 1));
            if (x.size < 10000000)   //1250000
            {
                switch (y.toLowerCase()) {
                    case 'jpg':
                    case 'jpeg':
                    case 'png':
                    case 'gif':
                    case 'bmp':

                        $("#File1").prop("files")[0].uploAdattachName = $scope.winattachmentname;
                        $("#File1").prop("files")[0].uploAdattachType = $scope.model.IdProof;
                        $scope.Uploads.push($("#File1").prop("files")[0]);
                        $scope.Uploads[len].IsUploaded = false;
                        $scope.Uploads[len].IsVehicle = false;
                        $scope.Uploads[len].IsPAN = false;
                        $scope.hasIdAttach = true;
                        $scope.$apply();
                        $scope.WinAttachment.close();
                        break;
                    default:
                        ShowMessage('Invalid file type. Only jpg,jpeg,png,gif,bmp are allowed', 'W');
                }
            }
            else {
                ShowMessage('File size must be less than 10MB', 'W');
            }
        }
    }



    $scope.AddVehicleFile = function () {
        var len = $scope.Uploads.length;
        if ($("#File2").prop("files")[0] != undefined) {
            var x = $("#File2").prop("files")[0];
            var y = x.name.substr((x.name.lastIndexOf('.') + 1));
            if (x.size < 10000000)   //1250000
            {
                switch (y.toLowerCase()) {
                    case 'jpg':
                    case 'jpeg':
                    case 'png':
                    case 'gif':
                    case 'bmp':

                        $("#File2").prop("files")[0].uploAdattachName = $scope.winvehicleattachmentname;
                        $("#File2").prop("files")[0].uploAdattachType = $scope.model.VehicleProof;
                        $scope.Uploads.push($("#File2").prop("files")[0]);
                        $scope.Uploads[len].IsUploaded = false;
                        $scope.Uploads[len].IsVehicle = true;
                        $scope.Uploads[len].IsPAN = false;
                        $scope.hasVehicleAttach = true;
                        $scope.$apply();
                        $scope.WinVehicleAttachment.close();
                        break;
                    default:
                        ShowMessage('Invalid file type. Only jpg,jpeg,png,gif,bmp are allowed', 'W');
                }
            }
            else {
                ShowMessage('File size must be less than 10MB', 'W');
            }
        }
    }

    $scope.AddPANFile = function () {
        var len = $scope.Uploads.length;
        if ($("#File3").prop("files")[0] != undefined) {
            var x = $("#File3").prop("files")[0];
            var y = x.name.substr((x.name.lastIndexOf('.') + 1));
            if (x.size < 10000000)   //1250000
            {
                switch (y.toLowerCase()) {
                    case 'jpg':
                    case 'jpeg':
                    case 'png':
                    case 'gif':
                    case 'bmp':

                        $("#File3").prop("files")[0].uploAdattachName = $scope.winPANname;
                        $("#File3").prop("files")[0].uploAdattachType = $scope.model.PAN;
                        $scope.Uploads.push($("#File3").prop("files")[0]);
                        $scope.Uploads[len].IsUploaded = false;
                        $scope.Uploads[len].IsVehicle = false;
                        $scope.Uploads[len].IsPAN = true;
                        $scope.hasPANAttach = true;
                        $scope.$apply();
                        $scope.WinPANAttachment.close();
                        break;
                    default:
                        ShowMessage('Invalid file type. Only jpg,jpeg,png,gif,bmp are allowed', 'W');
                }
            }
            else {
                ShowMessage('File size must be less than 10MB', 'W');
            }
        }
    }

    $scope.DeleteAttachment = function (id) {
        var warnText = "Are you sure you want to delete this attachment?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                var Id = id;
                $http({
                    method: 'POST',
                    url: baseUrl + 'Fastag/DeleteAttachment?Id=' + Id,
                   
                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg();
                    if (response.data == 'success') {
                      
                        var ParentId = $scope.model.Id;
                        $scope.GetAttachments(ParentId);
                        
                    }
                    else {
                        SetMessage('Error');
                    }



                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });
    }

    $scope.DeleteUpload = function (id) {
        var warnText = "Are you sure you want to delete this attachment?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                debugger;
                $scope.hasVehicleAttach = false;
                $scope.hasPANAttach = false;
                $scope.hasIdAttach = false;
                $scope.Uploads.splice(id, 1);
                $scope.$apply();
                for (var i = 0; i < $scope.Uploads.length; i++) {
                    if ($scope.Uploads[i].IsVehicle == 1) {

                        $scope.hasVehicleAttach = true;

                    }
                    if ($scope.Uploads[i].IsVehicle == 0 && $scope.Uploads[i].IsPAN == 1) {
                        $scope.hasPANAttach = true;
                    }
                    if ($scope.Uploads[i].IsVehicle == 0 && $scope.Uploads[i].IsPAN == 0) {
                        $scope.hasIdAttach = true;
                    }
                }

            }
        });
    };



    $scope.VehicleTypeDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Vehicle Type",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "Setting/GetVehicleType"
                }
            }
        },
        filter: "contains",
        suggest: true
    };

    $scope.OnVehicleTypeComboBoxChange = function (e) {
        debugger;
        $scope.Settings = {};
        var valid = comboBoxClearInavlidEntry(e);
        if (!valid) {
            // SetComboValue("BranchId", null);

        }
        else {
            var vehicleTypeId = getComobBoxValue("VehicleTypeId");
            $scope.ShowLoaderImg();
            $http({
                method: 'GET',
                url: baseUrl + 'Setting/GetConfiguration?Id=' + vehicleTypeId,

            }).then(function (response) {
                debugger;

                var result = [];
                var tot = 0;
                $scope.details = [];
                if (response.data.length > 0) {
                    for (var i = 0; i < response.data.length; i++) {
                        tot = response.data[i].FastagFee + response.data[i].MinimumBalanceWalletDeposit + response.data[i].RefundableSecurityDeposit + response.data[i].Others;
                        result.push({ FastagFee: response.data[i].FastagFee, MinimumBalanceWalletDeposit: response.data[i].MinimumBalanceWalletDeposit, RefundableSecurityDeposit: response.data[i].RefundableSecurityDeposit, Others: response.data[i].Others, Total: tot });
                        $scope.model.FastagFee = response.data[i].FastagFee;
                        $scope.model.MinimumBalanceDeposit = response.data[i].MinimumBalanceWalletDeposit;
                        $scope.model.SecurityDeposit = response.data[i].RefundableSecurityDeposit;
                        $scope.model.Others = response.data[i].Others;
                        $scope.model.TotalPayable = tot;

                    }
                    $scope.CanProceed = true;
                }
                else {
                    $scope.CanProceed = false;
                    SetMessage('NoData');

                }
                $scope.details = result;
                $scope.Settings = $scope.details;
                $scope.HideLoaderImg();

            }, function errorCallback(response) {
                $scope.HideLoaderImg();


            });
        }
    };


    $scope.CheckForSuccess = function () {
        var len = $filter('filter')($scope.Uploads, function (d) { return d.IsUploaded == true });
        if (len.length == $scope.Uploads.length) {
            $scope.HideLoaderImg();
        }
    }



    $scope.submitFiles = function (Id) {

        $scope.uploadedCount = 0;
        $scope.totaluploads = $scope.Uploads.length;
        var attachIndex = 0;
        if ($scope.Uploads.length > 0) {
            for (var i = 0; i < $scope.Uploads.length; i++) {
                attachIndex++;
                $scope.UploadFileIndividual(Id, attachIndex,
                                            $scope.Uploads[i],
                                            $scope.Uploads[i].name,
                                            $scope.Uploads[i].uploAdattachName,
                                            $scope.Uploads[i].uploAdattachType,
                                            $scope.Uploads[i].type, i);
            }
        }

    }

    $scope.UploadFileIndividual = function (Id, attachIndex, fileToUpload, name, uploAdattachName,uploadType, type, index) {
        //Create XMLHttpRequest Object
        debugger;
        var reqObj = new XMLHttpRequest();
        //event Handler
        reqObj.upload.addEventListener("progress", uploadProgress, false)
        reqObj.addEventListener("load", uploadComplete, false)
        reqObj.addEventListener("error", uploadFailed, false)
        reqObj.addEventListener("abort", uploadCanceled, false)
        //open the object and set method of call(get/post), url to call, isasynchronous(true/False)
        reqObj.open("POST", "/Fastag/UploadFiles", true);
        //set Content-Type at request header.For file upload it's value must be multipart/form-data
        reqObj.setRequestHeader("Content-Type", "multipart/form-data");
        //Set Other header like file name,size and type                
        reqObj.setRequestHeader('X-File-Path', "/Content/Fastag/"); //set folder path for attachment save
        reqObj.setRequestHeader('X-Reference-Table', "");
        reqObj.setRequestHeader('X-Reference-Id', parseInt(Id));
        reqObj.setRequestHeader('X-File-Name', encodeURIComponent(name));
        reqObj.setRequestHeader('X-File-GivenName', encodeURIComponent(uploAdattachName));
        reqObj.setRequestHeader('X-File-IdType', encodeURIComponent(uploadType));
        reqObj.setRequestHeader('X-File-Type', type);
        reqObj.setRequestHeader('X-File-IsVehicle', fileToUpload.IsVehicle);
        reqObj.setRequestHeader('X-File-IsPAN', fileToUpload.IsPAN);
        //  reqObj.setRequestHeader('X-File-AllocateId', $scope.model.Id);
        if (($scope.Uploads.length == attachIndex) || ($scope.Uploads.length == 1)) {     //checking the last file upload
            reqObj.setRequestHeader('X-Deleted-DocId', $scope.DeletedAttachId);
        }
        else {
            reqObj.setRequestHeader('X-Deleted-DocId', '');
        }
        reqObj.setRequestHeader('X-IsContain-Upload', true);
        // send the file
        reqObj.send(fileToUpload);

        function uploadProgress(evt) {
            $scope.ShowLoaderImg();
            if (evt.lengthComputable) {
                var uploadProgressCount = Math.round(evt.loaded * 100 / evt.total);
                if (uploadProgressCount == 100) {
                }

            }
        }
        function uploadComplete(evt) {
            /* This event is raised when the server  back a response */
            $scope.ShowLoaderImg();
            $scope.uploadedCount++;
            $scope.Uploads[index].IsUploaded = true;
            $scope.NoOfFileSaved++;
            $scope.CheckForSuccess();
            if (parseInt($scope.uploadedCount) == parseInt($scope.totaluploads)) {
                OncomplteAttach();
            }
            $scope.$apply();
        }

        function uploadFailed(evt) {
            OncomplteAttach();
        }

        function uploadCanceled(evt) {
        }
    }


    function OncomplteAttach() {
        $scope.totaluploads = 0;
        $scope.uploadedCount = 0;
        $scope.HideLoaderImg();
        //$scope.WinReplaceRequest.close();
        //$scope.MobilizationGrid.dataSource.read();
        //SetMessage("Save", null, "PopUp", "#MobilizationGrid .btn-add");

    }

    $scope.Cancel = function () {

        window.location = "/Fastag/List";
    }
    $scope.mergeFile = function () {

        $scope.ShowLoaderImg();
        $http({
            method: 'GET',
            url: baseUrl + 'Fastag/download',

        }).then(function (response) {
            debugger;
            $scope.HideLoaderImg()


        }, function errorCallback(response) {
            $scope.HideLoaderImg();
            SetMessage('Error');

        });

    };


    $scope.ChangeTotal = function (obj) {
        if ($scope.model.SecurityDeposit == '' || $scope.model.SecurityDeposit == undefined || $scope.model.SecurityDeposit == null)
            $scope.model.SecurityDeposit = 0;

        if ($scope.model.FastagFee == '' || $scope.model.FastagFee == undefined || $scope.model.FastagFee == null)
            $scope.model.FastagFee = 0;

        if ($scope.model.MinimumBalanceDeposit == '' || $scope.model.MinimumBalanceDeposit == undefined || $scope.model.MinimumBalanceDeposit == null)
            $scope.model.MinimumBalanceDeposit = 0;

        if ($scope.model.Others == '' || $scope.model.Others == undefined || $scope.model.Others == null)
            $scope.model.Others = 0;


        $scope.model.TotalPayable = parseFloat($scope.model.SecurityDeposit) + parseFloat($scope.model.FastagFee) + parseFloat($scope.model.MinimumBalanceDeposit) + parseFloat($scope.model.Others);
        $scope.$apply();
    }


    $scope.CheckBalance = function (e) {
        if ($scope.model.FromAccountNumber == "" || $scope.model.FromAccountNumber == null || $scope.model.FromAccountNumber == undefined) {
            WarnMessage("Please enter Customer A/C No.");
            return false;

        }
        else {
            $scope.ShowLoaderImg();
            $http({
                method: 'POST',
                url: baseUrl + 'Fastag/CheckAccountBalance?Id=' + $scope.model.FromAccountNumber,

            }).then(function (response) {
                debugger;
                $scope.HideLoaderImg();
                alert(response.data);

            }, function errorCallback(response) {
                $scope.HideLoaderImg();


            });
        }
    }


    


});

function AddFile() {
    $("#FastagRegistrationController").scope().AddFile();
}

function AddVehicleFile() {
    $("#FastagRegistrationController").scope().AddVehicleFile();
}
function AddPANFile() {
    $("#FastagRegistrationController").scope().AddPANFile();
}
function ClickUpload() {
    if ($("#winattachmentname").val() == "") {
        $("#winattachmentnameErr").show();
        return false;
    }
    else {
        $("#TypeErr").hide();
        $("#winattachmentnameErr").hide();
        $("#File1").click();
    }
}

function ClickVehicleUpload() {
    if ($("#winvehicleattachmentname").val() == "") {
        $("#winvehicleattachmentname").show();
        return false;
    }
    else {
        $("#TypeErr").hide();
        $("#winvehicleattachmentErr").hide();
        $("#File2").click();
    }
}

function ClickPANUpload() {
    if ($("#winPANname").val() == "") {
        $("#winPANname").show();
        return false;
    }
    else {
        $("#TypeErr").hide();
        $("#winPANattachmentErr").hide();
        $("#File3").click();
    }
}


$(document).ready(function () {
    //$("#File1").click(function () {
    //    this.value = null;
    //});

    //$("#File2").click(function () {
    //    this.value = null;
    //});
    //$("#File3").click(function () {
    //    this.value = null;
    //});
});
