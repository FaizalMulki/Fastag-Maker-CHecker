﻿app.controller("SettingController", function ($scope, $http,$filter) {
    $scope.model = {};  
    $scope.model.txtSearch = "";
    $scope.HideLoaderImg = function () {
        $('#LoadingImg').hide();
    }

    $scope.ShowLoaderImg = function () {
        $('#LoadingImg').show();
    }

    $scope.Search = function () {
        $("#mainGrid").data("kendoGrid").dataSource.read();
    }

    $scope.mainGridOptions = {
        dataSource: {
            type: "json",
            transport: {
                read: {
                    url: baseUrl + "Setting/GetAllItems",
                    dataType: "json",
                },
                parameterMap: function (options, operation) {
                    debugger;
                    var opt = {};
                    opt = options;
                    opt.Search = $scope.model.txtSearch;
                    return opt;
                },
            },
            schema:
                    {
                        model:
                        {
                            id: "Id",
                            fields: {

                            }
                        }
                    },

            serverPaging: true,
            schema: {
                data: function (response) {
                    if (response.Result) {
                        return JSON.parse(response.Result);
                    }
                    return [];
                },
                total: 'Total',

            }
        },

        sortable: {
            mode: "single",
            allowUnsort: true
        },


        pageable: { pageSize: GridPageSize, refresh: true },

        resizeable: true,
        scrollable: false,
     
        columns: [
               {
                   field: "VehicleType",
                   title: "Type",
                   width: "80px",
                   filterable: false,

               },
                {
                    field: "EffectiveFrom",
                    title: "From",
                    width: "160px",
                    type: "date",
                   format: "{0:dd-MMM-yyyy}"

                },
                 {
                     field: "EffectiveTo",
                     title: "To",
                     width: "160px",
                     type: "date",
                     format: "{0:dd-MMM-yyyy}"

                 },
                 {
                     field: "RefundableSecurityDeposit",
                     title: "Deposit",
                     width: "100px",
                     filterable: false,

                 },
                 {
                     field: "FastagFee",
                     title: "Fastag Fee",
                     width: "80px",
                     filterable: false,
                 },
                 {
                     field: "MinimumBalanceWalletDeposit",
                     title: "Min.Deposit",
                     width: "80px",
                     filterable: false,
                 },
                 {
                     field: "Others",
                     title: "Others ",
                     width: "80px",
                     filterable: false,
                 },
                  {
                      field: "CreatedBy",
                      title: "Created By ",
                      width: "80px",
                      filterable: false,
                  },
                  {
                      field: "CreatedDate", title: "Created Date", width: "80px",
                      type: "date",
                      format: "{0:dd-MMM-yyyy}"
                  },
                  

           {
               template: "<a href='javascript:void(0);' class='btn-edit'  ng-click='GroupPopup(this)'  data-toggle='tooltip' title='Edit'><i class='las la-pen'></i></a> &nbsp; <a href='javascript:void(0);' class='btn-delete' ng-click='deleteSetting(this)'  data-toggle='tooltip' title='Delete'><i class='las la-trash-alt'></i></a>",
               width: "40px",
               title: "Action",
               headerAttributes: { style: "text-align:center;" },
               attributes: { style: "text-align:center;" },
           },

        ]
    };
    

    $scope.AddSetting = function (e) {
        $("span.k-tooltip-validation").hide();
        $scope.clearFields();
        $scope.winOptions = {
            title: "Add (New)",
        }
        $scope.WinGroup.setOptions($scope.winOptions);
        $scope.WinGroup.open().center();
    }

    $scope.GroupPopup = function (e) {
        debugger
        $("span.k-tooltip-validation").hide();
        if (e.dataItem != null) {
            var dataItem = e.dataItem;
            if (dataItem) {
                $scope.model.Id = dataItem.Id;               
                $scope.model.VehicleType = dataItem.VehicleType;
                SetComboValue("VehicleTypeId", dataItem.VehicleTypeId);
                $scope.model.RefundableSecurityDeposit = dataItem.RefundableSecurityDeposit;
                $scope.model.FastagFee = dataItem.FastagFee;
                $scope.model.MinimumBalanceWalletDeposit = dataItem.MinimumBalanceWalletDeposit;
                $scope.model.Others = dataItem.Others;
                $scope.model.EffectiveFrom = kendo.toString(dataItem.EffectiveFrom, 'dd-MMM-yyyy');
                $scope.model.EffectiveTo = kendo.toString(dataItem.EffectiveTo, 'dd-MMM-yyyy');

                $scope.model.BtnName = "Update";


           


            }
            else {
                $scope.clearFields();
            }
        }
        else {
           
            $scope.clearFields();
            $scope.model.BtnName = "Submit";
        }


        $scope.winOptions = {
            title: dataItem == null ? "Add (New)" : "Edit",
          
        }
        $scope.WinGroup.setOptions($scope.winOptions);
        $scope.WinGroup.open().center();

    };


  
    $scope.clearFields = function () {
        $scope.model = {};    
        $scope.model.Id = "";
        $scope.model.EffectiveFrom = "";
        $scope.model.EffectiveTo = "";
        $scope.model.VehicleType = "";
        $scope.model.VehicleTypeId = "";
        SetComboValue("VehicleTypeId", null);
        $scope.model.RefundableSecurityDeposit = "";
        $scope.model.FastagFee = "";
        $scope.model.MinimumBalanceWalletDeposit = "";
        $scope.model.Others ="";
        $scope.model.BtnName = "Submit";
       
    }

    $scope.Cancel = function (e) {
        $scope.WinGroup.close();
    };

    $scope.Save = function () {
        debugger
        if ($scope.validator.validate()) {
            $scope.ShowLoaderImg();
            var Setting =
               {
                   Id: $scope.model.Id,
                   EffectiveFrom:$scope.model.EffectiveFrom,
                   EffectiveTo: $scope.model.EffectiveTo,
                   VehicleTypeId: getComobBoxValue("VehicleTypeId"),
                   RefundableSecurityDeposit: $scope.model.RefundableSecurityDeposit,
                   FastagFee: $scope.model.FastagFee,
                   MinimumBalanceWalletDeposit: $scope.model.MinimumBalanceWalletDeposit,
                   Others: $scope.model.Others
               };

            $http({
                method: 'POST',
                url: baseUrl + 'Setting/SubmitInfo',
                data: Setting,
            }).then(function (response) {
                debugger;
                $scope.HideLoaderImg();
                if (response.data == 'error') {
                    SetMessage('Error')
                }
                else if (response.data == 'exists') {
                    SetMessage('VehicleExist')
                }
                else {
                    $scope.WinGroup.close();
                    SetMessage('Save')
                    $("#mainGrid").data("kendoGrid").dataSource.read();
                }

            }, function errorCallback(response) {
                $scope.HideLoaderImg();
                SetMessage('Error');

            });


        }
    }


   
 

    $scope.deleteSetting = function (e) {
        $scope.DeleteModel = {};
        var warnText = "Are you sure you want to delete this record?";
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                $scope.DeleteModel.VehicleTypeId = e.dataItem.VehicleTypeId;
                $http({
                    method: 'POST',
                    url: baseUrl + 'Setting/Delete',
                    data: $scope.DeleteModel,
                }).then(function (response) {
                    debugger;
                    $scope.HideLoaderImg();
                    if (response.data == 'dependency') {
                        SetMessage('CantDelete')
                    }
                    else if (response.data == 'success') {
                        SetMessage('Delete')
                    }
                    else {
                        SetMessage('Error');
                    }

                    $("#mainGrid").data("kendoGrid").dataSource.read();


                }, function errorCallback(response) {
                    $scope.HideLoaderImg();
                    SetMessage('Error');

                });
            }
        });
    }




    $scope.OnVehicleTypeComboBoxChange = function (e) {
        debugger;
        var valid = comboBoxClearInavlidEntry(e);
    }
   
    $scope.VehicleTypeDataSource = {
        dataTextField: "Name",
        dataValueField: "Id",
        placeholder: "Vehicle Type",
        dataSource: {
            transport: {
                read: {
                    type: "GET",
                    dataType: "json",
                    url: baseUrl + "Setting/GetVehicleType"
                }
            }
        },
        filter: "contains",
        suggest: true
    };

});